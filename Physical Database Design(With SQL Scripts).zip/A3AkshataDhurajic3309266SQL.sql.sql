
DROP TABLE Acquisition
DROP TABLE Reservation
DROP TABLE LOAN
DROP TABLE Staff
DROP TABLE Student
DROP TABLE Members
DROP TABLE ImmovableResources
DROP TABLE MovableResources
DROP TABLE Resources
DROP TABLE StudentCourseOffering
DROP TABLE Location
DROP TABLE CategoryPrivileges
DROP TABLE CoursePrivileges
DROP TABLE ImmovableResourcesDtls
DROP TABLE MovableResourcesDtls
DROP TABLE StaffMembers
DROP TABLE StudentMembers
DROP TABLE CourseOffering
DROP TABLE Privilege
DROP TABLE Category
Drop sequence privilegeSeq
Drop Sequence categorySeq 
Drop Sequence courseOfferSeq
Drop Sequence locationSeq 
Drop Sequence loanSeq 
Drop Sequence reservationSeq 
Drop Sequence acquisitionSeq


Create table Members (
member_Number	 		CHAR(10) NOT NULL PRIMARY KEY,
member_Name				CHAR(50) NOT NULL,
phone_Num				INT NOT NULL,
email 					CHAR(50) NOT NULL,
						CHECK (len(email) - len(replace(email,'@',''))=1 AND len(email) - 
						len(replace(email,'.',''))=1 AND CHARINDEX('!',email)!>0 AND 
						CHARINDEX('#',email)!>0 AND CHARINDEX('%',email)!>0 AND 
						CHARINDEX('�',email)!>0 AND CHARINDEX('"',email)!>0),
Address 				CHAR(100),
member_Type 			CHAR(20) NOT NULL,
member_Status 			CHAR(10) DEFAULT 'Active' CHECK (member_Status IN ('Active', 'Expire')) NOT NULL,  
penalty_Points 			INT NOT NULL DEFAULT 12);
GO

Create table Staff (
member_Number 		CHAR(10) NOT NULL PRIMARY KEY FOREIGN KEY References Members(member_Number)
On Update Cascade On delete cascade,
activity			CHAR(10) DEFAULT 'Academic' CHECK (activity IN ('Academic', 'Research')) NOT NULL);
GO

Create table Category (
category_Code 			INT Not Null Primary Key,
category_Name 			CHAR(15) NOT NULL,
category_Description 	CHAR(50) NOT NULL,
category_Duration 		CHAR(10) NOT NULL,
numOfResources 			INT NOT NULL);
GO

Create table Privilege (
privilege_Id 			INT NOT NULL Primary Key,
privilege_Name 			CHAR(20) NOT NULL,
privilege_Description 	CHAR(50) NOT NULL,
category_Code 			INT Foreign Key references Category(category_Code) 
						On Update Cascade On Delete Set NULL,
course_OfferingId 		CHAR(10) NOT NULL,
max_Resource_Brw  		INT NOT NULL,
max_Period_Brw			INT	NOT NULL);
GO

Create table CourseOffering (
course_OfferingId 	INT NOT NULL Primary Key,
privilege_Id 		INT NOT NULL DEFAULT 1 Foreign Key references Privilege(privilege_Id) 
					On Update Cascade On Delete Set Default,
course_Id 			INT NOT NULL,
course_Name			Char(20) NOT NULL,
semester			INT NOT NULL,
year 				CHAR(10) NOT NULL,
course_Startdate 	DATETIME NOT NULL,
course_Enddate 		DATETIME NOT NULL);
GO


Create table Student (
member_Number	 	CHAR(10) NOT NULL Primary Key Foreign Key references Members(member_Number) 
					On Update Cascade On Delete Cascade,
course_OfferingId 	INT Foreign Key references CourseOffering (course_OfferingId) 
					On Update Cascade On Delete Set NULL);
GO


Create table Location (
location_Id 		INT NOT NULL PRIMARY KEY,
location_Campus 	CHAR(50) NOT NULL,
location_Room 		CHAR(20) NOT NULL, 
location_Building	CHAR(20) NOT NULL);
Go


Create table Resources (
resource_Number 		CHAR(10) NOT NULL PRIMARY KEY,
category_Code 			INT NOT NULL DEFAULT '00' FOREIGN KEY REFERENCES Category(category_Code) ON UPDATE CASCADE ON DELETE SET DEFAULT,
location_Id 			INT NOT NULL DEFAULT '111' FOREIGN KEY REFERENCES Location(location_Id) 
						ON UPDATE CASCADE ON DELETE SET DEFAULT ,
resource_Name 			CHAR(20) NOT NULL,
resource_Description	CHAR(50) NOT NULL,
resource_Type 			CHAR(10) NOT NULL,
resource_Status 		CHAR(15) DEFAULT 'Available' CHECK (resource_Status IN ('Available', 'Occupied', 'Damaged'))NOT NULL,);
GO


Create table MovableResources (
resource_Number 	CHAR(10) NOT NULL PRIMARY KEY FOREIGN KEY REFERENCES Resources(resource_Number) 
					ON UPDATE CASCADE ON DELETE CASCADE, 
make 				CHAR(15) NOT NULL,
manufacturer 		CHAR(15) NOT NULL,
model				CHAR(15) NOT NULL,
year 				INT,
asset_Value			DECIMAL(10,2));
GO


Create table ImmovableResources (
resource_Number 	CHAR(10) NOT NULL PRIMARY KEY FOREIGN KEY REFERENCES Resources(resource_Number)
					ON UPDATE CASCADE ON DELETE CASCADE,
capacity 			CHAR(15) NOT NULL);
GO


Create table Acquisition (
Ac_Request_Number 	INT NOT NULL PRIMARY KEY,
member_Number 		CHAR(10) FOREIGN KEY REFERENCES Members(member_Number) 
					ON UPDATE CASCADE ON DELETE SET NULL,
category_Code 		INT FOREIGN KEY REFERENCES Category(category_Code) 
					ON UPDATE CASCADE ON DELETE NO ACTION ,
resource_Name 		CHAR(20) NOT NULL,
resource_Description CHAR(50) NOT NULL,
make 				CHAR(20) NOT NULL,
manufacturer 		CHAR(20) NOT NULL,
model 				CHAR(20) NOT NULL,
urgency 			CHAR(15) NOT NULL,
ac_Request_Status 	INT,
fund_id 			INT,
vendor_id 			INT,
price 				DECIMAL(10,2),
remarks 			CHAR(50));
GO


Create Table LOAN (
loan_Id 			INT NOT NULL PRIMARY KEY,
member_Number 		CHAR(10) FOREIGN KEY REFERENCES Members(member_Number)
					ON UPDATE CASCADE ON DELETE SET NULL,
resource_Number 	CHAR(10) FOREIGN KEY REFERENCES MovableResources (Resource_number) 
					On Delete Set Null On Update Cascade,
issue_DateTime 		DATETIME NOT NULL,
actual_ReturnDate 	DATETIME);
GO


Create table Reservation (
reservation_Number 		INT NOT NULL PRIMARY KEY,
member_Number 			CHAR(10) FOREIGN KEY REFERENCES Members(member_Number)
						ON UPDATE CASCADE ON DELETE SET NULL,
resource_Number 		CHAR(10) FOREIGN KEY REFERENCES Resources (Resource_number) 
						On Delete Set Null On Update Cascade,
request_DateTime 		DATETIME NOT NULL,
reservation_DateTime	DATETIME NOT NULL,
due_DateTime 			DATETIME NOT NULL,
reservation_Status		CHAR(10) NOT NULL);
GO

Create Sequence categorySeq start with 100 increment by 1

Create Sequence privilegeSeq start with 1 increment by 1

Create Sequence courseOfferSeq start with 110 increment by 1

Create Sequence locationSeq Start with 100 increment by 5

Create Sequence loanSeq start with 1000 increment by 1

Create Sequence reservationSeq start with 1000 increment by 1

Create Sequence acquisitionSeq start with 1000 increment by 1
GO

SELECT Student.member_Number as StudentNum,
Members.member_Name as StudentName,
CourseOffering.course_Name as CourseName,
CourseOffering.course_OfferingId as CourseNum, 
CourseOffering.year as CourseYear
INTO StudentCourseOffering
FROM Student 
INNER JOIN Members on Student.member_Number=Members.member_Number
INNER JOIN CourseOffering on Student.course_OfferingId=CourseOffering.course_OfferingId
GO

SELECT Student.member_Number as StudentNum, 
Members.member_Name as StudentName, 
Members.phone_Num as Phone,
Members.member_Status as Status
INTO StudentMembers
FROM Student 
INNER JOIN Members on Student.member_Number=Members.member_Number
GO

SELECT Staff.member_Number as StaffNum, 
Members.member_Name as StaffName, 
Members.phone_Num as Phone,
Members.member_Status as Status
INTO StaffMembers
FROM Staff 
INNER JOIN Members on Staff.member_Number=Members.member_Number
GO

SELECT ImmovableResources.resource_Number as ResourceNum,
Resources.resource_Name as Name,
Resources.resource_Description as Description,
Resources.resource_Status as Status,
ImmovableResources.capacity as Capacity
INTO ImmovableResourcesDtls
from Resources INNER JOIN ImmovableResources on Resources.resource_Number=ImmovableResources.resource_Number
GO

SELECT MovableResources.resource_Number as ResourceNum,
Resources.resource_Name as Name,
Resources.resource_Description as Description,
Resources.resource_Status as Status,
MovableResources.make as Make,
MovableResources.model as Model
INTO MovableResourcesDtls
from Resources INNER JOIN MovableResources on Resources.resource_Number=MovableResources.resource_Number
GO


SELECT CourseOffering.course_OfferingId AS CourseOfferingId,
CourseOffering.course_Name AS CourseName,
CourseOffering.year AS Year,
Privilege.privilege_Id AS PrivilegeNum,
Privilege.privilege_Description AS PrivilegeDescription
INTO CoursePrivileges
FROM CourseOffering INNER JOIN Privilege on CourseOffering.course_OfferingId=Privilege.course_OfferingId
GO

SELECT P.privilege_Id AS PrivilegeId, P.privilege_Name AS PrivilegeName, P.privilege_Description AS PrivilegeDescription,
C.category_Code AS CategoryCode, c.category_Name AS CategoryName, c.category_Description AS CategoryDescription, c.category_Duration AS DurationOfBorrow
INTO CategoryPrivileges 
FROM Privilege p INNER JOIN Category c on p.category_Code=c.category_Code
GO

insert into Members (member_Number, member_Name, phone_Num, email, Address, member_Type, member_Status, penalty_Points) 
values ('ST001', 'Robin', 84983741, 'robin@gmail.com', '337H Turana Parade NSW 404040 Australia','Student','Active', 12)
GO

insert into Members (member_Number, member_Name, phone_Num, email, Address, member_Type, member_Status, penalty_Points)
values ('SR001', 'Bob', 83453465, 'bobgoodwin@gmail.com', '550C Harrys Street NSW 646464 Australia','ReasearchStaff',DEFAULT, 12)
GO

insert into Members (member_Number, member_Name, phone_Num, email, Address, member_Type, member_Status, penalty_Points) 
values ('SA001', 'Neha', 56434356, 'nehajoshi@gmail.com', '66A Harrys Street NSW 646464 Australia','AcademicStaff',DEFAULT, 12),
('ST002', 'Heena', 84983741, 'henakhan@gmail.com', '55A Dukes Street NSW 420404 Australia','Student','Active', 12),
('ST003', 'Martin', 83453465, 'martinluther@gmail.com', '889R Nichole Street NSW 577433 Australia','Student','Active', 12),
('SR002', 'John', 83453465, 'JohnHopkins@gmail.com', '767A Cummins Street NSW 577433 Australia','ReasearchStaff','Expire', 12)
GO

Insert into Staff values 
('SA001','Academic'),
('SR001', 'Research'),	
('SR002', 'Research')
GO

Insert into Category values
(NEXT VALUE FOR categorySeq, 'SPKR', 'Speaker', 7 , 1),
(NEXT VALUE FOR categorySeq, 'CAM', 'Camera', 5 , 2),
(NEXT VALUE FOR categorySeq,'MIC','Microphone',2,6),
(NEXT VALUE FOR categorySeq, 'MET-RM', 'Meeting Romm', 1 , 100)
GO

Insert into Privilege values 
(NEXT VALUE FOR privilegeSeq, 'StudPrivSPKR001','Student Privileges on SPKR001', 100, 110, 3, 7),
(NEXT VALUE FOR privilegeSeq, 'StudPrivCAM001','Student Privileges on GoPro Camera type CAM001', 101, 111, 2, 7),
(NEXT VALUE FOR privilegeSeq, 'StudPrivMIC001','Student Privileges on Microphone type MIC001', 102, 111, 1, 5)
GO

Insert into CourseOffering values
(NEXT VALUE FOR courseOfferSeq, 1, 1,'BSCPHY', 2,'2020', '5/Feb/2020', '20/Dec/2020'),
(NEXT VALUE FOR courseOfferSeq, 2, 2,'BASOC', 4,'2020', '5/Feb/2020', '20/Dec/2021'),
(NEXT VALUE FOR courseOfferSeq, 1, 2, 'BSCCHEM', 4,'2020', '5/Feb/2020', '20/Dec/2021')
GO

Insert into Student values 
('ST001',110),
('ST002', 112),
('ST003', 111)
GO

Insert into Location values 
(NEXT VALUE FOR locationSeq, 'Callaghan', 'DorothyHill','Science001'),
(NEXT VALUE FOR locationSeq, 'Callaghan', 'Isobel','Science001'),
(NEXT VALUE FOR locationSeq, 'Callaghan', 'Clark','Science001'),
(NEXT VALUE FOR locationSeq, 'Callaghan', 'Robotics Lab','Science001'),
(NEXT VALUE FOR locationSeq, 'Callaghan', 'AC Storage','CT001'),
(NEXT VALUE FOR locationSeq, 'Sydney', 'Optical Store','ICT001')
GO

Insert into Resources values
('SPKR001', 100, 105,'Dolby speaker', 'Bose Soundlink Revolve+ Bluetooth Speaker', 'Movable', 'Available'), 
('CAM001', 101, 105,'GOPRO Action Camera', 'HERO9 Black Max Lens Mod', 'Movable', 'Damaged'),
('MIC001', 102, 110,'Aston Microphones', 'Aston Microphones Large Diaphragm Microphone', 'Movable', 'Available'),
('MIC002', 102, 105,'AKG C636 Microphone', 'Handheld Vocal Microphone', 'Movable', 'Available'),
('METRM001', 103, 115,'Champion', '16Seater with VC-facility', 'Immovable', 'Available'),
('METRM002', 103, 105,'Champion', '20Seater with Telecon Facility', 'Immovable', 'Available'),
('METRM003', 103, 110,'Champion', '50Seater audio-video Hall', 'Immovable', 'Available'),
('CAM002', 102, 105,'Digital Camera', 'Nikon Coolpix A900', 'Movable', 'Available')
GO

Insert into MovableResources values
('SPKR001', 'SoundLink', 'BOSE', 'Revolve+', 2020, 299.95),
('CAM001', 'GOPRO-CAM', 'GOPRO', 'HER09', 2019, 799.99),
('MIC001', 'Aston Mic', 'Aston','Large Diaphragm', 2020, 900.50),
('MIC002', 'AKG C636Mic','AKG', 'Handheld Mic', 2019, 549.99)
GO

Insert into Loan (loan_Id, member_Number, resource_Number, issue_DateTime) values 
(NEXT VALUE FOR loanSeq,'ST001', 'SPKR001', GETDATE()),
(NEXT VALUE FOR loanSeq,'ST002', 'CAM001', GETDATE()),
(NEXT VALUE FOR loanSeq,'ST003', 'MIC001', GETDATE()),
(NEXT VALUE FOR loanSeq,'SA001', 'SPKR001', '2020-08-25'),
(NEXT VALUE FOR loanSeq,'SR002', 'CAM001', '2020-08-15'),
(NEXT VALUE FOR loanSeq,'SR001', 'MIC001', '2020-08-01'),
(NEXT VALUE FOR loanSeq,'ST001', 'CAM001', '2020-08-25')
Go

Insert into Reservation values 
(NEXT VALUE FOR reservationSeq, 'SA001', 'MIC001', GETDATE(), '2020-10-27',
 DATEADD (Day,1,'2020-10-27'),'Failed'),
(NEXT VALUE FOR reservationSeq,'SR001', 'SPKR001',GETDATE(),'2020-10-25', 
DATEADD(DAY,1, '2020-10-25'),'Reserved'),
(NEXT VALUE FOR reservationSeq, 'SR002', 'MIC002', GETDATE(),'2020-10-25', 
DATEADD(DAY,1, '2020-10-25'),'Reserved'),
(NEXT VALUE FOR reservationSeq, 'ST001', 'METRM001', '2020-04-27', '2020-05-01',
 DATEADD (Day,1,'2020-05-01'),'Reserved'),
(NEXT VALUE FOR reservationSeq, 'ST001', 'METRM001', '2020-06-01', '2020-06-05',
 DATEADD (Day,1,'2020-06-05'),'Reserved'),
(NEXT VALUE FOR reservationSeq, 'ST001', 'METRM001', '2020-09-17', '2020-09-19',
 DATEADD (Day,1,'2020-09-19'),'Reserved')
 GO

Insert into Acquisition 
(Ac_Request_Number,member_Number,resource_Name,resource_Description,make,
manufacturer, model,urgency, ac_Request_Status, fund_id,vendor_id,price,remarks)
values
(NEXT VALUE FOR acquisitionSeq, 'ST001', 'Microphone', 'Cordless Microphone',
'2020', 'Truslink', 'L598', 'High', DEFAULT, 001, 121, 599.99, 'Approved  for purchase')
GO

Insert into Acquisition 
(Ac_Request_Number,member_Number,resource_Name,resource_Description,make,
manufacturer, model,urgency, ac_Request_Status, fund_id,vendor_id,price,remarks)
values
(NEXT VALUE FOR acquisitionSeq, 'ST002', 'Microphone', 'Cordless Microphone',
'2020', 'Truslink', 'L598', 'High', DEFAULT, 001, 121, 599.99, 'Approved for purchase'),
(NEXT VALUE FOR acquisitionSeq, 'ST003', 'Bluethooth Speaker', 'Bluethooth Speaker Surround Sound','2020', 'BOSE', 'AX598', 'High', DEFAULT, 001, 121, 699.99, 'Request On-Hold'),
(NEXT VALUE FOR acquisitionSeq, 'ST001', 'Speaker', 'SoundBar',
'2020', 'BOSE', 'N676', 'Medium', DEFAULT, 001, 121, 299.99, 'Approved for purchase'),
(NEXT VALUE FOR acquisitionSeq, 'SA001', 'Speaker', 'SoundBar',
'2020', 'BOSE', 'N676', 'Medium', DEFAULT, 001, 121, 299.99, 'Approved  for purchase'),
(NEXT VALUE FOR acquisitionSeq, 'SR002', 'Microphone', 'Cordless Microphone',
'2020', 'Truslink', 'L598', 'High', DEFAULT, 001, 121, 599.99, 'Approved  for purchase'),
(NEXT VALUE FOR acquisitionSeq, 'SR001', 'Bluethooth Speaker', 
'Bluethooth Speaker Surround Sound', '2020', 'BOSE', 'AX598', 'High', DEFAULT, 001, 121, 699.99, 'Request On-Hold')
GO

Create Index idxCourseName on CourseOffering (course_Name)
Create Index idxMemberName on Members (member_Name)
Create Index idxCategoryName on Category (category_Name)
Create Index idxIssueDate on LOAN (issue_DateTime)
Create Index idxResourceName on Resources (resource_Name)

select Members.member_Name from Members 
inner join Student on Members.member_Number= Student.member_Number
inner join CourseOffering on Student.course_OfferingId= CourseOffering.course_OfferingId
Where course_Name='BSCPHY'

Select max_Resource_Brw from Privilege 
inner join Category on Privilege.category_Code=Category.category_Code
inner join CourseOffering on CourseOffering.privilege_Id=Privilege.privilege_Id
inner join Student on Student.course_OfferingId=CourseOffering.course_OfferingId 
inner join Members on Members.member_Number = Student.member_Number
where category_Name='SPKR' and Members.member_Name='Robin'


select 
Members.member_Name, Members.phone_Num, 
count(distinct Acquisition.Ac_Request_Number)as Acquisition_Request,
count(distinct Reservation.reservation_Number) as Reservation_Request
from Members 
INNER JOIN Acquisition on Members.member_Number = Acquisition.member_Number
INNER JOIN Reservation on Members.member_Number = Reservation.member_Number
where Members.member_Number='ST001'
Group by Members.member_Name, Members.phone_num


select Members.member_Name,Resources.resource_Name, Category.category_Name from Members 
JOIN LOAN on Members.member_Number = LOAN.member_Number
JOIN MovableResources on LOAN.resource_Number=MovableResources.resource_Number
JOIN Resources on LOAN.resource_Number=Resources.resource_Number
JOIN Category on Resources.category_Code=Category.category_Code
Where MovableResources.model='HER09' AND MovableResources.year=2019


select MovableResources.resource_Number, Resources.resource_Name 
from MovableResources 
join Resources on MovableResources.resource_Number =Resources.resource_Number
join LOAN on MovableResources.resource_Number = LOAN.resource_Number
Where MONTH(issue_DateTime)=(select MONTH(Getdate()))


select FORMAT (Reservation.reservation_DateTime, 'MMM dd yyyy') as ReservationDate,
 	Resources.resource_Name as ResourceName, 
 	count( distinct (Reservation.reservation_Number)) as NumberOfReservations
 	from Resources
 	Join Reservation on Resources.resource_Number=Reservation.resource_Number
 	where resource_Name='Champion' AND 
(reservation_DateTime = '2020-09-19' OR reservation_DateTime = '2020-06-05' OR reservation_DateTime = '2020-05-01')
Group by Reservation.reservation_DateTime, Resources.resource_Name



