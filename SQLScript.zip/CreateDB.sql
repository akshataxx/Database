/*
Created by Group 16 - C3309266 Akshata Dhuraji and Atreyu Cortez
Assignment1 - Comp3350 Advanced Database
File Name - CreateDB.SQL
Purpose - Creates and inserts data in the table for Yummy database
*/

Drop table cardPayment
Drop table cashPayment
Drop table OnlineOrder
Drop table PhoneOrder
Drop table WalkInOrder
Drop table Deliveryorder
Drop table Pickuporder
Drop table OrderMenu
Drop table manager
Drop table shopworker
Drop table driverdetails
Drop table driver
Drop table EmployeePayment
Drop table EmployeeInfo
Drop table bankDetails
Drop table shiftDeliveryDriver
Drop table shiftShopWorker
Drop table shiftManager
Drop table Customer
Drop table ShiftData
Drop table Supplies
Drop table SupplierOrder
Drop table SupplierDetails
Drop table StockDetails
Drop table Ingredient
Drop table Menu
Drop table Discount

create table Discount (DiscountCode varchar(10) primary key not null, description varchar(100), 
						StartDate date not null, EndDate date not null, DiscountRequirement varchar(100) not null,
						DiscountPercentage dec(4,2) not null);
go

create table Menu (ItemCode varchar(10) primary key not null, nameMenu varchar(20) not null, 
					size varchar(20), SellingPrice dec(4,2) not null);
go

create table Ingredient (IngredientCode varchar(10) primary key not null,
						NameIngredient varchar(20), Type char(20), description char(20),
						Ingredientqtyused int not null, 
						ItemCode varchar(10) foreign key references Menu(ItemCode) on update cascade on delete set null); 

go

create table StockDetails (IngredientCode varchar(10) primary key, DateOfLastStockTake date,
							CurrentStockLevel varchar(20) not null, ReorderLevel varchar(20) not null,
							foreign key (IngredientCode) references Ingredient(IngredientCode) on
							update cascade on delete no action);
go 

create table SupplierDetails (ABN varchar(10) primary key not null, IngredientCode varchar(10) not null, SupplierName varchar(20), 
								SupplierPhone varchar(20), DeliveryDeadLine varchar(20), 
								foreign key (IngredientCode) references StockDetails(IngredientCode) on update
								cascade on delete no action);
go

create table SupplierOrder (SupplierOrderID varchar(10) primary key not null, IngredientCode varchar(10) not null, 
							ABN varchar(10) not null, Quantity varchar(20) not null, RecieptNumber numeric not null, TotalAmountDue 
							dec(6,2) not null, Subtotal dec(6,2) not null, PaymentStatus varchar(20), PaymentDate date,
							foreign key (ABN) references SupplierDetails(ABN) on update cascade on delete cascade,
							foreign key (IngredientCode) references StockDetails(IngredientCode) on update no action);


go 

create table Supplies (ABN varchar(10) not null, IngredientCode varchar(10) not null , quantityDifference varchar(20),
						primary key (ingredientCode,ABN),
						foreign key (ABN) references SupplierDetails(ABN) on update cascade on delete no action,
						foreign key (IngredientCode) references StockDetails(IngredientCode) on update no action);
go



create table ShiftData(ShiftID varchar(10) primary key not null, shiftStartTime time not null, shiftEndTime time not null, 
			shiftStartDate date not null , shiftEndDate date not null);
go


create table Customer (CustomerNo varchar(10) primary key not null, CustomerPhone int not null unique, CustomerName varchar(50), 
						addressCustomer varchar(50), CustomerEmail varchar(20), CustomerPassword varchar(30));
go 


create table shiftManager (ShiftID varchar(10) primary key not null, HoursworkedManager varchar(20),
							foreign key (ShiftID) references ShiftData(ShiftID) on update cascade
						on delete no action);
go


create table shiftShopWorker (ShiftID varchar(10) primary key not null, HoursWorked varchar(20),  
							 foreign key (ShiftID) references ShiftData(ShiftID) on update cascade 
							 on delete no action);
go

create table shiftDeliveryDriver (ShiftID varchar(10) primary key not null, DateOfDelivery datetime, NumofOrdersDel int,
								 foreign key (ShiftID) references ShiftData(ShiftID) on update cascade on delete no action);
go

create table bankDetails (AccountNum varchar(10) primary key not null, BSB int not null, BankName varchar(20));
go


create table EmployeeInfo (employeeNo varchar(10) primary key not null, firstname char(50), lastname char(50), postalAddress varchar(100),
			contactNumber varchar(20), taxfilenumber varchar(20) not null unique, ShiftID varchar(10) not null, AccountNum varchar(10)
			not null unique, statusEmployee varchar(10),description varchar(100), 
			foreign key (ShiftID) references ShiftData(ShiftID) on update cascade on delete no action,
			foreign key (AccountNum) references bankDetails(AccountNum) on update cascade on delete no action);
go

create table EmployeePayment(paymentID varchar(10) primary key not null, employeeNo varchar(10) not null,TotalPayOut dec(6,2) not null , PaymentStatus char(10), 
						paymentDate date not null , taxwithheld dec(5,2),
						foreign key (employeeNo) references EmployeeInfo (employeeNo) on update cascade on delete no action);
go


create table driver (employeeNo varchar(10) primary key not null, payperdelivery dec(4,2) not null,
						foreign key (employeeNo) references EmployeeInfo(employeeNo));
go 


create table driverdetails (employeeNo varchar(10) primary key not null, driverlicenseNo varchar(20) not null, registrationPlateNo varchar(20),
							foreign key (employeeNo) references driver(employeeNo) on update cascade on delete no action);

create table shopworker (employeeNo varchar(10) primary key not null, hourlyRate dec(4,2) not null,
						foreign key (employeeNo) references EmployeeInfo(employeeNo) on update cascade on delete no action);
go


create table manager (employeeNo varchar(10) primary key not null, hourlyPayManagerRate dec(4,2),
						foreign key (employeeNo) references EmployeeInfo(employeeNo));
go


create table OrderMenu (Order_Number int primary key not null, OrderDateTime datetime, CustomerType varchar(10), 
			CustomerPhone int default 0, ItemCode varchar(10) not null, QuantityOfItem int not null, 
			PriceOfItem dec(4,2) not null, 	totalAmountDue dec(4,2) not null, DiscountAmount dec(4,2) , 
			DiscountCode varchar(10) , tax dec(4,2) not null, DateTimeOrderNeedsFullfilling datetime ,
			DateTimeOrderComplete datetime,	DeliveryMode varchar(10), DeliveryAddress varchar(20),
			PaymentConfirmation varchar(10), OrderTakenBy varchar(10) ,
			foreign key  (ItemCode) references Menu(ItemCode) on update cascade on delete no action);
go

create table Pickuporder (Ordernum int primary key not null,  PickUpTime datetime not null,
				foreign key (Ordernum) references OrderMenu(Order_Number) on update cascade on delete no action );
go 

create table Deliveryorder (Ordernum int primary key not null,  DeliveryTime datetime not null, Deliverydriver varchar(10) not null, DeliveryAddress varchar(10)
				foreign key (Ordernum) references OrderMenu(Order_Number) on update cascade on delete no action);
go 

create table WalkInOrder (Ordernum int primary key not null, QueuingNumber varchar(10),
					foreign key (Ordernum) references OrderMenu(Order_Number) on update cascade on delete no action);
go


create table PhoneOrder (Order_Number int  primary key not null, Phonenum int,  
					foreign key (Order_Number) references OrderMenu(Order_Number) on update cascade on delete no 
					action);
go




create table OnlineOrder (Order_Number int primary key not null, Email varchar(50) not null , password varchar(100) not null,
					 foreign key (Order_Number) references OrderMenu(Order_Number) on update cascade on 
					 delete no action);
go


create table cashPayment(Order_Number int primary key not null, amount dec(4,2) not null, paymentApprovalNoCash varchar(20) not null,
					foreign key (Order_Number) references OrderMenu(Order_Number) on update cascade on 
					delete no action);
go

create table cardPayment(Order_Number int primary key not null, CardType varchar(20) not null, PaymentApprovalNoCard varchar(20) not null,
					foreign key (Order_Number) references OrderMenu(Order_Number) on update cascade on 
					delete no action);
go
---Add details to Discount table
insert into Discount values ('W3456', 'TastyDealz: By Two get 50% of the third', '2021-03-14', '2021-05-14', 'Buy two pizzas', 50)
insert into Discount values ('W3556', 'Yummy Add-ons: Add additional toppings, 5% off each topping', '2021-01-14', '2021-03-18', 'Pizza is purchased', 5)
insert into Discount values ('W3566', 'Yummy Add-ons 2.0: Add an extra pizza, 3% off next pizza', '2021-01-11', '2021-07-14', 'Pizza is purchased', 3)
insert into Discount values ('W3567', 'Yummy Add-ons 1.0: Add an extra pizza, 2% off lava cake', '2021-01-11', '2021-07-14', 'Pizza is purchased', 2)
--Add Menu details
insert into Menu values ('P9093', 'Sausage Pizza', '20 inches', '45.20')  
insert into Menu values ('P9032', 'Chicken Pizza', '15 inches ', '25.00')  
insert into Menu values ('P3405', 'Mushroom Pizza', '10 inches', '19.00')  
---Add Ingredient details
insert into Ingredient values ('Z4506', 'Sausage', 'Meat', 'Spiced sausage', 20,'P9093' )
insert into Ingredient values ('Z3204', 'Chicken', 'Meat', 'Marinated Chicken',1,'P9032')
insert into Ingredient values ('Z2103', 'Mushroom', 'Vegetable', 'Mushroom',20,'P3405' )
--Add Stock Details
insert into StockDetails values ('Z4506', '2021-03-07', '1', '500')
insert into StockDetails values ('Z3204', '2021-03-03', '300', '400')
insert into StockDetails values ('Z2103', '2021-03-15', '140', '130')
--Add Supplier Details
insert into SupplierDetails values ('3023455494', 'Z4506', 'Arduini Sausages', '02431379', '2021-04-15')
insert into SupplierDetails values ('1255634512', 'Z3204', 'Stekkles PLTY', '02343457', '2021-05-10')
insert into SupplierDetails values ('9634224518', 'Z2103', 'Shrooms Provider', '02475428', '2021-04-12')
--Add Supplier Order
insert into SupplierOrder values ('I0245', 'Z4506', '3023455494', '20', '0134214', '123.03', '6.15', 'Pending', '2021-04-17')
insert into SupplierOrder values ('I5442', 'Z3204', '1255634512', '50', '9342452', '90.57', '1.81', 'Completed', '2021-04-20')
insert into SupplierOrder values ('I9324', 'Z2103', '9634224518', '30', '4755350', '34.90', '1.16', 'Completed', '2021-05-01')
--Add Supplies
insert into supplies values ('3023455494', 'Z4506', '50')
insert into supplies values ('1255634512', 'Z3204', '100')
insert into supplies values ('9634224518', 'Z2103', '0')
--Add Shift data
insert into ShiftData values ('Q7482', '08:30:00', '16:30:00', '2021-01-12', '2021-01-17') 
insert into ShiftData values ('Q9234', '09:30:00', '17:30:00', '2021-01-12', '2021-01-19')
insert into ShiftData values ('Q1342', '15:30:00', '23:30:00', '2021-01-17', '2021-01-24')
insert into ShiftData values ('Q4536', '15:30:00', '23:30:00', '2021-01-17', '2021-01-21')
insert into ShiftData values ('Q2352', '14:30:00', '22:30:00', '2021-01-19', '2021-01-26')
insert into ShiftData values ('Q9043', '18:00:00', '00:00:00', '2021-01-16', '2021-01-21')
--Add Customer data
insert into Customer values ('13416345', 0412564987, 'James Fee', '11 Blinked Street', 'jc08@yahoo.com', 'yopo999') 
insert into Customer values ('76464545', 0495310477, 'Adam Paul', '11 Slinker Street', 'krystal08@yahoo.com', 'orville42') 
insert into Customer values ('23434495', 0475472347, 'Lee Rodriguez', '11 Hyde Avenue', 'jason08@gmail.com', 'slinky231') 
insert into Customer values ('56356721', 0456235124, 'Azlan Gee', '34 Pole Avenue', 'ag124@gmail.com', 'Apex909')
--Add ShiftManager data
insert into shiftManager values ('Q7482', '34')
--Add shiftShopWorker data
insert into shiftShopWorker values ('Q9234', '29')
insert into shiftShopWorker values ('Q4536', '45')
insert into shiftShopWorker values ('Q9043', '26')
--Add shiftDeliveryDriver data
insert into shiftDeliveryDriver values ('Q1342', '2021-01-12', 23)
insert into shiftDeliveryDriver values ('Q2352','2021-01-12' , 2 )
--Add Bank Details of the Employee
insert into bankDetails values ('24556654', 679255, 'MoneyBank')
insert into bankDetails values ('83950254', 479435, 'BankDoll')
insert into bankDetails values ('96634554', 346732, 'EZBank')
insert into bankDetails values ('43532141', 679255, 'MoneyBank')
insert into bankDetails values ('64143526', 479435, 'BankDoll')
insert into bankDetails values ('41345642', 640000, 'CommsBank')
--Add Employee Information
insert into EmployeeInfo values ('OL748', 'Mick', 'Jagger', '25 Yard Road', '04782899', '90232421', 'Q7482',  '96634554', 'Employed', 'Very Good')
insert into EmployeeInfo values ('OL124', 'Nick', 'Livingston', '12 Palace Avenue', '04958672', '56422421', 'Q9234', '24556654', 'Employed', 'Very Good')
insert into EmployeeInfo values ('OL532', 'Amy', 'Fitz', '124 Mary Road', '04725754', '24218584', 'Q1342',  '83950254', 'Employed', 'Not Good')
insert into EmployeeInfo values ('OL902', 'Olivia', 'Crave', '19 Wollomi Avenue', '04235925', '09424912', 'Q4536', '43532141', 'Employed', 'Decent')
insert into EmployeeInfo values ('OL781', 'Peter', 'Pan', '123 Imaginary Road', '04348913', '24154424', 'Q2352',  '64143526', 'Terminated', 'Fought with Customer')
insert into EmployeeInfo values ('OL434', 'Isabella', 'Belbin', '65 Pete Street', '04135246', '74635625', 'Q9043',  '41345642', 'Employed', 'Decent')
--Add EmployeePayment Data
insert into EmployeePayment values ('U12578','OL748', '1245.04', 'Pending', '2021-01-22', '735.91')
insert into EmployeePayment values ('U24515','OL124', '903.45', 'Completed', '2021-01-21', '293.21')
insert into EmployeePayment values ('U24615','OL532', '1000.45', 'Completed', '2021-01-21', '356.11')
insert into EmployeePayment values ('U83100', 'OL781','782.00', 'Pending', '2021-01-29', '245.18')
insert into EmployeePayment values ('U32690', 'OL434','983.10', 'Completed', '2021-01-23', '503.01')
--Add Driver details
insert into driver values ('OL124', 25.00)
insert into driver values ('OL781', 00.00)
--Add Driver Details
insert into driverdetails values ('OL124', '1234245356', 'BP 45 90')
insert into driverdetails values ('OL781', '2345672891', null)
--Add Shop worker data
insert into shopworker values ('OL748', 22.50)
insert into shopworker values ('OL434', 23.50)
--Add manager data
insert into manager values ('OL532', 46.00)
insert into manager values ('OL902', 45.00)
--Add OrderMenu data
insert into OrderMenu values (5 , '2021-01-12 13:44:00','Walk-in' , 0412564987, 'P9093', 2,  12.00, 24.50, null, null, 2.00,'2021-01-12 13:44:00','2021-01-12 13:44:00','Pick-up', Null,'Paid' , 'OL748' ) 
insert into OrderMenu values ( 6, '2021-01-14 17:10:00','Online', 0495310477, 'P9032', 3,  9.00, 33.50, 4.50, 'W3456', 2.00,'2021-01-12 13:44:00','2021-01-12 13:44:00', 'Delivery', 'Turana parade', 'Paid', 'OL124' )
insert into OrderMenu values (7, '2021-01-15 10:39:14','Phone' , 0475472347, 'P3405', 3,  7.00, 21.50, 3.50, 'W3566', 3.50,'2021-01-15 10:39:14','2021-01-15 10:39:14', 'Pick-up', Null, 'Paid' ,'OL748')
insert into OrderMenu values (8, '2021-01-19 21:30:01', 'Walk-in', 0456235124,  'P9093', 1,  12.00, 13.50, null, null, 1.50, '2021-01-19 21:30:01','2021-01-19 21:30:01','Pick-up',Null, 'Paid','OL4348' )
--Add data to Pickup Order 
insert into Pickuporder values (5, '2021-01-12 13:44:00')
--Add data to Delivery Order
insert into Deliveryorder values (7, '2021-01-12 13:44:00', 'OL124', 'NSW' )
--Add data to Walkin Order
insert into WalkInOrder values (5, '0495310477')
insert into WalkInOrder values (8, '0412564987')
--Add data to Phone Order
insert into PhoneOrder values (7, '0456235124')
--Add data to Online Order
insert into OnlineOrder values (6, 'jason08@gmail.com', 'people123')
--Add data to Cash Payment
insert into cashPayment values (5, 24.50, '123456789')
--Add data to Card Payment
insert into cardPayment values (6, 'Amex', '42424352')
insert into cardPayment values (7, 'Visa', '90131235')

