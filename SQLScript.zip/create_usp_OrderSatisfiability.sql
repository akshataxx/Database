/*
Created by Group 16 - C3309266 Akshata Dhuraji and Atreyu Cortez
Assignment1 - Comp3350 Advanced Database
File Name - create_usp_OrderSatisfiability.SQL
Purpose - Creates Trigger as per the section 5 specification

Section 5: Business Rule: Order Satisfiability
Before an order can be taken, it is important to verify that the order can be satisfied 
with the available ingredients in the store. If the ingredients available are insufficient 
to fulfill the order an appropriate error message needs to be generated and the order 
cancelled. 
Ensure that the above business rule is enforced in the database. You need to generate 
appropriate error messages if an attempt to violate the constraint is attempted.

*/

--Sequence created to generate unique Order number
Drop SEQUENCE OrderNumSeq 
CREATE SEQUENCE OrderNumSeq 
start with 100 increment by 1 minvalue 0 maxvalue 10000000 cycle;

--check if the trigger exist drop it
Drop trigger if Exists CHK_INGREDIENT_INSTORE;
Go
CREATE trigger CHK_INGREDIENT_INSTORE 
ON OrderMenu 
FOR INSERT, UPDATE
AS BEGIN
		--keep track of the quantity required for the item
		DECLARE @qty_required_foritem int
		-- keep track of the ingredient in the stock
		DECLARE @ingredient_stock_level int
		DECLARE @errorMessage VARCHAR(2000)
		DECLARE @error INT
		
		SET @error = 0
		SET @errorMessage = ''
	BEGIN
		-- Declare Cursor
		DECLARE myCursor CURSOR
		FOR
		--Get the quantity of ingredient in stock
		SELECT  s.CurrentStockLevel  
		FROM StockDetails s , Ingredient i, Menu m, OrderMenu o
		WHERE o.ItemCode = (SELECT ItemCode FROM INSERTED) and
			o.ItemCode=m.ItemCode and
			m.ItemCode=i.ItemCode and
			i.IngredientCode=s.IngredientCode;
		--Open cursor
		OPEN myCursor

		FETCH NEXT FROM myCursor INTO  @ingredient_stock_level
		-- Determine the quantity of ingredient required for the item
		-- Ingredient used/required for the item
			SELECT  @qty_required_foritem =i.Ingredientqtyused 
			FROM  Ingredient i, Menu m, OrderMenu o
			WHERE	o.ItemCode = (SELECT  ItemCode FROM INSERTED) and
					o.ItemCode=m.ItemCode and
					m.ItemCode=i.ItemCode;
			IF (@qty_required_foritem > @ingredient_stock_level) 
		
		-- While there are rows that violate the policy
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @error = 1 -- An violation of policy occurred
			SET @errorMessage =  @errorMessage + 'Ingredient is lesser than the required qty for the item - Action failed'
			-- Get next row
			FETCH NEXT FROM myCursor INTO @ingredient_stock_level
		END
	-- Close cursor
	CLOSE myCursor

	-- Deallocate cursor
	DEALLOCATE myCursor
	
	-- If the policy is violated
	IF @error = 1
		BEGIN
			-- Raise the error with all created error string
			RAISERROR(@errorMessage, 10, 1)
			
			-- Rollback the transaction
			ROLLBACK TRANSACTION			
		END
	END
END
go

