/*
Created by Group 16 - C3309266 Akshata Dhuraji and Atreyu Cortez
Assignment1 - Comp3350 Advanced Database
File Name - test_usp_OrderSatisfiability.SQL
Purpose - Test Trigger 
Special Instruction - Run CreateDB.sql before running this code
*/

---Testing with mutiple rows
--This should Pass
insert into OrderMenu values (NEXT VALUE FOR OrderNumSeq,'2021-01-12 13:00:00', 'walkin',0412564987,	'P9032', 1,	25.00,	50.00, 0, 'W3556' ,	
10.50,	'2021-01-12 13:00:00',	'2021-01-12 13:44:00','Delivery','TuranaParade','paid', 'OL123' )
insert into OrderMenu values (NEXT VALUE FOR OrderNumSeq,'2021-01-12 13:00:00', 'walkin',0412564987,	'P9032', 1,	25.00,	50.00, 0, 'W3556' ,	
10.50,	'2021-01-12 13:00:00','2021-01-12 13:44:00','Delivery','TuranaParade','paid', 'OL748' ) --pass

--This should Fail with error msg --Ingredient is lesser than the required qty for the item - Action failed 
insert into OrderMenu values (NEXT VALUE FOR OrderNumSeq ,'2021-01-12 13:00:00','walkin',	0412564987,	'P9093', 1, 25.00, 50.00, 0,'W3556' ,
10.50,'2021-01-12 13:00:00','2021-01-12 13:44:00','Delivery','TuranaParade','paid', 'OL123' ) 

