/*
Created by Group 16 - C3309266 Akshata Dhuraji and Atreyu Cortez
Assignment1 - Comp3350 Advanced Database
File Name - test_usp_createCustomerOrder_group16.SQL
Purpose - Test Stored Procedure 
Special Instruction - Execute CreateDB.Sql prior to running this file
*/

---Testing---
EXEC usp_createCustomerOrder @CustomerId='13416345', @Inum= 'P9032', @Iqty = 2, @DiscountCode= 'W3456',
@CustType='Walk-in', @OrderDate ='2021-01-20 13:44:00', @DatetimeOrderNeedsFullfiling='2021-01-20 16:00:00',
@DateOrderComplete='2021-01-20 16:00:10', @DeliveryMode= 'Pickup', @paymentConfirmation ='Paid', 
@OrderTakenBy='OL748' --Successfully inserts record in OrderMenu and prints "Your Order Number is @Orderno
GO
-----Testing Fail case---------
EXEC usp_createCustomerOrder @CustomerId='13416345', @Inum= 'P9093', @Iqty = 2, @DiscountCode= 'W3456',
@CustType='Walk-in', @OrderDate ='2021-01-20 13:44:00', @DatetimeOrderNeedsFullfiling='2021-01-20 16:00:00',
@DateOrderComplete='2021-01-20 16:00:10', @DeliveryMode= 'Pickup', @paymentConfirmation ='Paid', 
@OrderTakenBy='OL748' --Shows Error "Ingredient is out of stock"
GO



