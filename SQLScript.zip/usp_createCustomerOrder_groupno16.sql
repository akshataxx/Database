/*
Created by Group 16 - C3309266 Akshata Dhuraji and Atreyu Cortez
Assignment1 - Comp3350 Advanced Database
File Name - usp_CreateCustomerOrder_group16.SQL
Purpose - Creates Stored Procedure as per assignment specifications
Special Instruction - Execute CreateDB.SQL before running this code
*/
--Drop Sequence and procedure if already exist
Drop SEQUENCE OrderNumSeq 
Drop PROCEDURE usp_createOrderItem,usp_createCustomerOrder
Drop type ItemQtyType


--Create Sequence to generate unique Order number
CREATE SEQUENCE OrderNumSeq 
start with 100 increment by 1 minvalue 0 maxvalue 10000000 cycle;
GO
--TVC For Item type used to add Item number and quantity details as per the assignment specificaiton
Create type ItemQtyType as Table
	(ItemNumber varchar(10) not null primary key,
	Quantity int not null)
GO
/* Stored procedure called from the parent stored procedure Create customer order this procedure uses TVC 
   to insert data into the OrderMenu table and returns Order number to the parent stored procedure*/
CREATE PROCEDURE usp_createOrderItem @ItemQtyList ItemQtyType READONLY 
AS
BEGIN
	DECLARE @ItemNo varchar(10),
			@ItemQty int
	-- Declare a cursor to traverse the input parameter row by row
	DECLARE curItemList CURSOR 	FOR SELECT ItemNumber, Quantity FROM @ItemQtyList FOR READ ONLY 
	-- Open the cursor
	OPEN curItemList
	-- Fetch first row
	FETCH NEXT FROM curItemList INTO @ItemNo, @ItemQty
	WHILE @@FETCH_STATUS = 0
	BEGIN
		DECLARE @price decimal(4,2)
		DECLARE @tot decimal(4,2)
		DECLARE @tax dec(4,2)
		DECLARE @ordernum int
		--Generate Order number
		SET @ordernum = NEXT VALUE FOR  OrderNumSeq
		--Get Price of the Item from Menu
		SELECT @price = SellingPrice
		from Menu where ItemCode = @ItemNo
		--Calculate Total Price
		SET @tot=@price*@ItemQty
		SET @tax= @tot * 0.1
		-- Update the Item row
		BEGIN
			Insert into OrderMenu (Order_Number, ItemCode, QuantityOfItem,PriceOfItem, totalAmountDue,tax)
			values ( @Ordernum,@ItemNo,@ItemQty,@price,@tot,@tax)
			Return @Ordernum
		END
	-- Fetch the next row
	FETCH NEXT FROM curItemList INTO @ItemNo, @ItemQty
	
	END -- End of While
	
	-- Close Cusor
	CLOSE curGradeList
	
	-- Deallocate cursor
	DEALLOCATE curGradeList
END
GO
/* Parent stored procedure calls the procedure usp_createOrderItem. It accepts input parameters as per 
   the assignent specification and inserts data into the OrderMenu table as long as all conditions are met 
   else it throws an error*/
Create Procedure usp_createCustomerOrder
(@CustomerId varchar(10), @Inum varchar(10), @Iqty int,  @DiscountCode varchar(10),@CustType varchar(10),
 @OrderDate datetime, @DatetimeOrderNeedsFullfiling datetime, @DateOrderComplete datetime, 
 @DeliveryMode varchar(10), @paymentConfirmation varchar(10), @OrderTakenBy varchar(10))
AS
BEGIN
	DECLARE @Orderno int
	DECLARE @phone int
	DECLARE @discountpercentage dec(4,2)
	DECLARE @discountamt dec(4,2)
	DECLARE @DeliveryAddress varchar(20)
	DECLARE @price decimal(4,2)
	DECLARE @temp decimal(4,2)
	DECLARE @tempstock int
	DECLARE @stocklevel int
	DECLARE @tempIUsed int
	DECLARE @IUsed int
	DECLARE @IngCode varchar(10)
	DECLARE @Itemlist ItemQtyType

	--update variables based on the contents of the table
	SELECT @phone = CustomerPhone from dbo.Customer where CustomerNo = @CustomerId
	SELECT @discountpercentage= DiscountPercentage from Discount where DiscountCode = @DiscountCode
	SELECT @price = SellingPrice from Menu where ItemCode = @Inum
	
	SET @temp= @price*@Iqty
	SET @discountamt= FLOOR((@discountpercentage * @temp)/100)--calculate discount amount based on the cost
	
	--Check current stock level of the ingredient
	SELECT @tempstock=CurrentStockLevel from StockDetails where IngredientCode=(Select IngredientCode
	from Ingredient where ItemCode=@Inum)
	SELECT @tempIUsed=Ingredientqtyused, @IngCode=IngredientCode from Ingredient where ItemCode=@Inum
	
	SET @IUsed= @tempIUsed*@Iqty -- Calculate the qty to be reduced from the stock
	SET @stocklevel=@tempstock-@IUsed
	--check if delivery mode is pickup then delivery address is null
	IF  CHARINDEX ('Pickup', @DeliveryMode) != 0
	BEGIN
		SET @DeliveryAddress=NULL
	END
	--If ingredient exist in the stock only then take the order	
	IF(@stocklevel >= @IUsed)
	BEGIN 
		--Calls the sub stored procedure and accepts and prints the Order number created
		Insert into @Itemlist values(@Inum, @Iqty)
		EXEC @Orderno=usp_createOrderItem @Itemlist 
		PRINT 'Your Order Number is ' + CAST(@Orderno as varchar(10))
		--Updates other order attributes
		UPDATE ORDERMENU SET OrderDateTime =@OrderDate , CustomerType= @CustType,CustomerPhone=@phone,
		DiscountAmount=@discountamt, DiscountCode=@DiscountCode, DeliveryAddress = @DeliveryAddress,
		DateTimeOrderNeedsFullfilling=@DatetimeOrderNeedsFullfiling, DateTimeOrderComplete=@DateOrderComplete, 
		DeliveryMode=@DeliveryMode, PaymentConfirmation=@paymentConfirmation, OrderTakenBy=@OrderTakenBy
		WHERE Order_Number=@Orderno
		--updates stock details to reduce the stock level 
		UPDATE StockDetails SET CurrentStockLevel= @stocklevel where IngredientCode=@IngCode
	END
	ELSE -- show error message
	BEGIN
		RAISERROR ('Ingredient is out of stock', 10, 1)
	END
END



